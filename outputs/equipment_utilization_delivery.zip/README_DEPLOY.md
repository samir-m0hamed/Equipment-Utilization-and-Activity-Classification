# Equipment Utilization Delivery Bundle

## Contents
- annotated.mp4: visual output
- events.jsonl: frame-level events
- summary.csv: per-equipment totals
- analytics_day3.db: SQLite analytics database
- activity_mix.csv / fragmentation_audit.csv / tracking_health.csv: dashboard-ready tables
- qa_report.json / qa_report.md: integrity checks

## Quick Validation
1. Confirm qa_report.json status is PASS or WARN.
2. Open tracking_health.csv and review max_tracks_per_equipment.
3. Use analytics_day3.db in dashboard notebook cells.

## Notes
- Bundle is generated from current OUTPUT_DIR only.
- Regenerate after each new pipeline run.