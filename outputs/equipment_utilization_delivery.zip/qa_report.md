# QA Report

- status: PASS
- generated_at_utc: 2026-04-09T00:29:44.637799+00:00

## Metrics
- total_events: 16228
- summary_rows: 7
- unique_equipment_ids: 7
- active_frame_ratio_pct: 56.51
- avg_utilization_pct: 69.55
- max_tracks_per_equipment: 15
- active_waiting_rows: 0
- active_none_rows: 0
- orphan_events: 0
- null_key_field_rows: 0
- non_monotonic_tracked_rows: 0
- non_monotonic_idle_rows: 0