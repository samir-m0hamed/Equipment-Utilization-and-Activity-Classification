# Baseline Foundation - Run in Google Colab

Use the cells below in order.

## 1) Install dependencies
```python
!pip -q install -r /content/repo/requirements/baseline.txt
```

## 2) (Optional) Confirm GPU
```python
import torch
print('CUDA available:', torch.cuda.is_available())
print('Device count:', torch.cuda.device_count())
```

## 3) Prepare paths
```python
import os

REPO_DIR = '/content/repo'
INPUT_VIDEO = '/content/input.mp4'   # change this
OUTPUT_DIR = '/content/outputs_baseline'
os.makedirs(OUTPUT_DIR, exist_ok=True)
```

## 4) Run baseline pipeline
```python
!python /content/repo/colab/baseline_foundation/pipeline.py \
  --input_video "$INPUT_VIDEO" \
  --output_dir "$OUTPUT_DIR" \
    --weights yolov8x.pt \
  --tracker bytetrack.yaml \
  --device 0 \
    --imgsz 1280 \
    --max_det 300 \
    --conf 0.20 \
    --iou 0.55 \
    --min_box_area 2500 \
    --motion_smooth_window 5 \
  --arm_motion_thr 1.2 \
  --base_motion_thr 0.9 \
  --state_smooth_window 7 \
    --state_active_votes 4 \
    --allowed_class_names excavator "dump truck" truck bulldozer loader backhoe
```

## 5) Quick check outputs
```python
import os
for f in sorted(os.listdir(OUTPUT_DIR)):
    print(f)
```
Expected files:
- annotated.mp4
- events.jsonl
- summary.csv

## 6) Preview event samples
```python
import json

events_path = f"{OUTPUT_DIR}/events.jsonl"
with open(events_path, 'r', encoding='utf-8') as f:
    for i, line in enumerate(f):
        if i >= 5:
            break
        print(json.dumps(json.loads(line), indent=2))
```

## 7) Preview summary
```python
import pandas as pd
summary = pd.read_csv(f"{OUTPUT_DIR}/summary.csv")
summary
```

## 8) Download artifacts
```python
from google.colab import files

files.download(f"{OUTPUT_DIR}/annotated.mp4")
files.download(f"{OUTPUT_DIR}/events.jsonl")
files.download(f"{OUTPUT_DIR}/summary.csv")
```

---

## If detector misses construction machines
Use your fine-tuned weights instead of `yolov8x.pt`:
```python
--weights /content/your_model.pt
```

This is expected in the baseline milestone. We will improve class/activity quality in the next milestones.
